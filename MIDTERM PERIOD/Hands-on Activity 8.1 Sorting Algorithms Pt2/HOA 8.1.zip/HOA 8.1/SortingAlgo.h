#ifndef SORTINGALGO_H
#define SORTINGALGO_H

#include <iostream>

const int MAX_STACK_SIZE = 100;

//Shell Sort
template<typename T>
void shellSort(T array[], int size) {
    for (int gap = size / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < size; i++) {
            T temp = array[i];
            int key = i;
            while (key >= gap && array[key - gap] > temp) {
                array[key] = array[key - gap];
                key -= gap;
            }
            array[key] = temp;
        }
    }
}

//Merge helper function
template<typename T>
void merge(T array[], int left, int mid, int right) {
    int sizeL = mid - left + 1;
    int sizeR = right - mid;

    T arrL[MAX_STACK_SIZE];
    T arrR[MAX_STACK_SIZE];

    for (int i = 0; i < sizeL; i++) {
        arrL[i] = array[left + i];
    }
    for (int j = 0; j < sizeR; j++) {
        arrR[j] = array[mid + 1 + j];
    }

    int i = 0, j = 0, k = left;

    while (i < sizeL && j < sizeR) {
        if (arrL[i] <= arrR[j]) {
            array[k] = arrL[i];
            i++;
        } else {
            array[k] = arrR[j];
            j++;
        }
        k++;
    }

    while (i < sizeL) {
        array[k] = arrL[i];
        i++;
        k++;
    }

    while (j < sizeR) {
        array[k] = arrR[j];
        j++;
        k++;
    }
}

//Merge Sort
template<typename T>
void mergeSort(T array[], int left, int right) {
    if (left >= right) return;
    int mid = left + (right - left) / 2;
    mergeSort(array, left, mid);
    mergeSort(array, mid + 1, right);
    merge(array, left, mid, right);
}

//Partition helper
template<typename T>
int partition(T arr[], int low, int high) {
    T pivot = arr[high];
    int i = low - 1;

    for (int j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            //swapping
            T temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    //swapping for pivot
    T temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;

    return i + 1;
}

//Quick Sort
template<typename T>
void quickSort(T arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

//Partition then Merge Sort 
template <typename T>
void partiMerge(T arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        mergeSort(arr, low, pi - 1);
        mergeSort(arr, pi + 1, high);
        merge(arr, low, pi, high);
    }
}

//Partition then Shell Sort 
template<typename T>
void partiShell(T arr[], int size) {
    int pi = partition(arr, 0, size - 1);
    shellSort(arr, size);
}

#endif