#include <iostream>
#include <cstdlib>
#include <ctime>
#include "SortingAlgo.h"

const int maxSize = 100;

// Function prototype
void displayArr(const int arr[]);

int main() {
    //declare array
    int originalArr[maxSize];
    int quickArr[maxSize];
    int mergeArr[maxSize];
    int shellArr[maxSize];

    //random number generation
    srand(time(0));

    //fill array with random values
    for (int i = 0; i < maxSize; i++) {
        originalArr[i] = rand() % 1000;
        
        //copy array values
        quickArr[i] = originalArr[i];
        mergeArr[i] = originalArr[i];
        shellArr[i] = originalArr[i];
    }

    //Display unsorted array
    std::cout << "-----------------UNSORTED ARRAY-----------------\n";

    displayArr(originalArr);

    //Sorting Algorithms 
    quickSort(quickArr, 0, maxSize - 1);
    partiMerge(mergeArr, 0, maxSize - 1);
    partiShell(shellArr, maxSize);

    //display results
    std::cout << "\n-----------------SORTED ARRAY RESULTS-----------------\n";

    std::cout << "\n Quick Sort Result \n";
    displayArr(quickArr);

    std::cout << "\n Merge Sort Result \n";
    displayArr(mergeArr);

    std::cout << "\n Shell Sort Result \n";
    displayArr(shellArr);

    return 0;
}

// formatted display
void displayArr(const int arr[]) {
    for (int i = 0; i < maxSize; i++) {
        std::cout << arr[i] << "\t";
        if ((i % 10) == 9) {
            std::cout << '\n';
        }
    }
}`