#include <iostream>
#include <chrono>
#include "SORTINGALGO_H"

void printArray(const int arr[], int size) {
    for (int i = 0; i < size; i++) {
        std::cout << arr[i] << (i == size - 1 ? "" : " ");
    }
    std::cout << "\n";
}

int main() {
    const int SIZE = 15;
    int dataset[SIZE] = {4, 34, 29, 48, 53, 87, 12, 30, 44, 25, 93, 67, 43, 19, 74};

    int quickArr[SIZE];
    int mergeArr[SIZE];
    int shellArr[SIZE];

    for (int i = 0; i < SIZE; i++) {
        quickArr[i] = dataset[i];
        mergeArr[i] = dataset[i];
        shellArr[i] = dataset[i];
    }

    std::cout << "-----------------RUNTIME & TIME COMPLEXITY-----------------\n";
    std::cout << "Input Array (N = " << SIZE << "):\n";
    printArray(dataset, SIZE);

    std::cout << "[EMPIRICAL RUNTIME MEASUREMENTS]\n";

    //Quick Sort
    auto startQuick = std::chrono::high_resolution_clock::now();
    quickSort(quickArr, 0, SIZE - 1);
    auto endQuick = std::chrono::high_resolution_clock::now();
    auto durationQuick = std::chrono::duration_cast<std::chrono::nanoseconds>(endQuick - startQuick).count();

    //Merge Sort
    auto startMerge = std::chrono::high_resolution_clock::now();
    mergeSort(mergeArr, 0, SIZE - 1);
    auto endMerge = std::chrono::high_resolution_clock::now();
    auto durationMerge = std::chrono::duration_cast<std::chrono::nanoseconds>(endMerge - startMerge).count();

    //Shell Sort
    auto startShell = std::chrono::high_resolution_clock::now();
    shellSort(shellArr, SIZE);
    auto endShell = std::chrono::high_resolution_clock::now();
    auto durationShell = std::chrono::duration_cast<std::chrono::nanoseconds>(endShell - startShell).count();

    //Print results 
    std::cout << "Quick Sort Execution Time : " << durationQuick << " ns\n";
    std::cout << "Merge Sort Execution Time : " << durationMerge << " ns\n";
    std::cout << "Shell Sort Execution Time : " << durationShell << " ns\n";

    return 0;
}