#include <iostream>

#include "node.h"
#include "searchingAlgo.h"

const int max_size = 10;

int main() {
    int itemToFind = 8;
    int dataset[max_size] = {3, 5, 6, 8, 11, 12, 14, 15, 17, 18};

    binarySearchArr(dataset, max_size, itemToFind);

    return 0;
}

