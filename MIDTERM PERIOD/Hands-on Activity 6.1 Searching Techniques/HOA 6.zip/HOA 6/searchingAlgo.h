#include "node.h"
#include <iostream>

#ifndef SEARCHINGALGO_H
#define SEARCHINGALGO_H

//----------------------- ARRAY --------------------------

template<typename T>
int RecBinarySearchArr(T data[], int low, int high, T dataFind, int iteration) { 
    if (low > high) {
        std::cout << "Data not found\n";
        return -1;
    }

    int mid = (low + high) / 2; 
        
    std::cout << "Iteration: " << iteration << ": low= " << low << ": high= " << high << ": middle= " << mid << ": value= " << data[mid] << "\n";
        
    if (dataFind == data[mid]) {
        std::cout << "Match found at index: " << mid << std::endl;
        return mid;
    }
    else if (dataFind < data[mid]) {
        return RecBinarySearchArr(data, low, mid - 1, dataFind, iteration + 1);
    }
    else {
        return RecBinarySearchArr(data, mid + 1, high, dataFind, iteration + 1);
    }
}

template<typename T>
void binarySearchArr(T data[], int arrSize, T dataFind) {
    RecBinarySearchArr(data, 0, arrSize - 1, dataFind, 1);
}

#endif


//----------------------- LINKED LIST --------------------------

/*template <typename T>
void binarySearchLL(Node<T>* start, T dataFind) {
    Node<T>* last = nullptr;
    
    while (start != last) {
        Node<T>* middle = getMiddle(start, last);

        if (middle->data == dataFind) {
            std::cout << "Data found\n";
            return;
        }
        else if (middle->data > dataFind) {
            last = middle;
        }
        else {
            start = middle->next; 
        }
    }

    std::cout << "Data not found\n";
}
*?
template<typename T>
Node<T>* getMiddle(Node<T>* start, Node<T>* end){
    Node<T>* slow = start;
    Node<T>* fast = start;

    while (fast != end && fast->next!= end){
        slow = slow->next;

        fast = fast->next->next;
    }

    return slow;
}

/*
template<typename T>
void linearSearch(int size,T item,T array[]){
    int count = 0;
    for (int i = 0; i < size;i++){
        if(array[i] == item){
            count++;
        }
    }
    if (count > 0){
        std::cout << item << " appears " << count << " number of times." << std::endl;
    }
    else {
        std::cout << "data not found!" << std::endl;
    }
}
*/
/*
template<typename T>
void linearSearchLL(Node<T> *headNode, T dataToBeFound){
    int count = 0;
    while (headNode != nullptr){
        if (headNode->data == dataToBeFound){
            count++;
        }
        headNode = headNode->next;
    }
    if (count > 0){
        std::cout << dataToBeFound << " appears " << count << " number of times." << std::endl;
    }
    else {
        std::cout << "data not found!" << std::endl;
    }
}
*/