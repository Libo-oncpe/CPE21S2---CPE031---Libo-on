#ifndef NODE_H
#define NODE_H

template<typename T>
class Node{
    public:
    T data;
    Node* next;
};

template<typename T>
Node<T>* newNode(T newData){
    Node<T> *newNode = new Node<T>;
    newNode->data = newData;
    newNode->next = nullptr;
    return newNode;
}

template<typename T>
void delNodes(Node<T>** head){
    Node<T>* current = *head;
    while (current != nullptr) {
        Node<T>* nextNode = current->next;
        delete current;
        current = nextNode;
    }
    *head = nullptr; // Reset the head pointer to avoid a dangling pointer
}

#endif