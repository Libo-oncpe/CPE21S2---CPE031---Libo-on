#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <chrono>
#include <algorithm> 
#include "supplementary.h"

const int SIZE = 100;

void displayArray(const int arr[]) {
    for (int i = 0; i < SIZE; i++) {
        std::cout << arr[i] << " ";
    }
    std::cout << "\n";
}

void countAndPrintVotes(const int votes[], const std::string candidates[]) {
    int voteCounts[5] = {0};

    //counts the occurance of numbers of candidates
    for (int i = 0; i < SIZE; i++) {
        voteCounts[votes[i] - 1]++;
    }

    //winner detector
    int maxVotes = -1;
    int winnerIndex = 0;

    //candidate display function with their specific numbers and votes
    for (int i = 0; i < 5; i++) {
        std::cout << "Candidate " << (i + 1) << " (" << candidates[i] << "): " 
                  << voteCounts[i] << " votes\n";
        if (voteCounts[i] > maxVotes) {
            maxVotes = voteCounts[i];
            winnerIndex = i;
        }
    }

    std::cout << " WINNER: " << candidates[winnerIndex] 
              << " with " << maxVotes << " votes!\n";
}

//candidates list
int main() {
    std::string candidates[5] = {
        "Bo Dalton Capistrano",
        "Cornelius Raymon Agustin",
        "Deja Jayla Banaga",
        "Lalla Brielle Yabut",
        "Franklin Relano Castro"
    };

    int originalVotes[SIZE];
    int testVotes[SIZE];

    //random number generator from 1-5
    std::srand(static_cast<unsigned int>(std::time(0))); 
    for (int i = 0; i < SIZE; i++) {
        originalVotes[i] = std::rand() % 5 + 1;
    }
    std::cout << "-------ELECTION VOTE TALLY -------\n\n";
    std::cout << "----------------------------------------\n";
    std::cout << "UNSORTED VOTES:\n";
    displayArray(originalVotes);
    std::cout << "----------------------------------------\n\n";

    //BUBBLE SORT
    std::copy(originalVotes, originalVotes + SIZE, testVotes);
    auto start = std::chrono::high_resolution_clock::now();
    
    bubbleSort(testVotes, SIZE);
    //checks the execution time of the sorting technique
    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
    
    //displays the result and execution time
    std::cout << "1. BUBBLE SORT:\n";
    countAndPrintVotes(testVotes, candidates);
    std::cout << " Execution Time: " << duration.count() << " microseconds\n\n";
    

    //SELECTION SORT 
    std::copy(originalVotes, originalVotes + SIZE, testVotes);
    start = std::chrono::high_resolution_clock::now();
    
    selectionSort(testVotes, SIZE);
    //checks the execution time of the sorting technique
    stop = std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);

    //displays the result and execution time
    std::cout << "2. SELECTION SORT:\n";
    countAndPrintVotes(testVotes, candidates);
    std::cout << " Execution Time: " << duration.count() << " microseconds\n\n";
    

    //INSERTION SORT 
    std::copy(originalVotes, originalVotes + SIZE, testVotes);
    start = std::chrono::high_resolution_clock::now();
    
    insertionSort(testVotes, SIZE);
    //checks the execution time of the sorting technique
    stop = std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);

    //displays the result and execution time
    std::cout << "3. INSERTION SORT:\n";
    countAndPrintVotes(testVotes, candidates);
    std::cout << " AExecution Time: " << duration.count() << " microseconds\n\n";
    
    return 0;
}