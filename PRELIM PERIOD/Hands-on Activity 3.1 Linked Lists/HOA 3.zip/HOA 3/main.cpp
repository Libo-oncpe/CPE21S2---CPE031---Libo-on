#include <iostream>
#include <string>
#include <limits>
#include "Sample_ll.h" 

int main (){

    music_playlist<std::string>* head = nullptr;
    int choice;

            do {
                std::cout << "\n===== MUSIC PLAYLIST =====\n";
                std::cout << "1. Add Song\n";
                std::cout << "2. View All Songs\n";
                std::cout << "3. Next Song\n";
                std::cout << "4. Previous Song\n";
                std::cout << "5. Remove Song\n";
                std::cout << "6. Exit\n";
                std::cout << "Enter choice: ";
                std::cin >> choice;

                switch (choice) {

                    case 1:
                    {   
                        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                        std::string song, artist;
                        std::cout << "Enter new music: ";
                        std::getline(std::cin, song);
                        std::cout << "Enter artist name: ";
                        std::getline(std::cin, artist);
                        addmusic<std::string>(song, artist, &head);
                        break;
                    }

                    case 2:
                    {
                        std::cout << "\nPlaylist:\n";
                        view_all_music(head);
                        break;
                    }

                    case 3:
                    {
                        next_music(head);
                        break;
                    }

                    case 4:
                    {
                        prev_music(head);
                        break;
                    }

                    case 5:
                    {
                        int number;
                        std::cout << "Enter a song number to remove: ";
                        std::cin >> number;
                        Del_music(number, &head);
                        break;
                    }

                    case 6:
                    {
                        std::cout << "Exiting Playlist.\n";
                        break;
                    }

                    default:
                    {
                        std::cout << "Invalid choice.\n";
                    }           
                }
            } while (choice != 6);
    return 0;
}