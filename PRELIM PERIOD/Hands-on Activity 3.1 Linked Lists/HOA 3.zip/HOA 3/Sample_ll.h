#ifndef S_DOUBLE_LL_H
#define S_DOUBLE_LL_H
#include <iostream> 
#include <string>           

//blueprint for the song
template <typename T>
class music_playlist{
    public:
        T data;
        std::string artist;
        music_playlist<T>* next; // for storing the next song
        music_playlist<T>* prev; // for storing the prev song
};

//Creating nodes
template <typename T>
music_playlist<T>* new_Node(T newData, std::string newArtist){
    //Dynamic allocation for a new node
    music_playlist<T>* newNode = new music_playlist<T>;
    //store the music in a new node
    newNode->data = newData;
    newNode->artist = newArtist;
    //Point it to null after
    newNode->next = nullptr;
    newNode->prev = nullptr;
    return newNode;                     
}

//MUSIC INSERTION
template <typename T>
void addmusic(T newData, std::string newArtist, music_playlist<T>** currenthead){
    //create a new node
    music_playlist<T>* newNode = new_Node(newData, newArtist);
    //If playlist is empty
    if(*currenthead == nullptr){
        //the first song points back to itself
        newNode->next = newNode;
        newNode->prev = newNode;
        *currenthead = newNode;
        return;
    }
    //Get the last node
    music_playlist<T>* tail = (*currenthead)->prev;
    //connect last node to a new node
    newNode->next = *currenthead;
    newNode->prev = tail;
    tail->next = newNode;
    (*currenthead)->prev = newNode;
    
};

//Next song
template <typename T>
void next_music(music_playlist<T>*& currentnode){
    if (currentnode == nullptr){
        std::cout << "Playlist is empty. \n";
        return;
    }
    currentnode = currentnode->next; 
    std::cout << "Currently Playing: " << currentnode->data << " by " << currentnode->artist << "\n";
};

// Previous 
template <typename T>
void prev_music(music_playlist<T>*& currentnode){
    if (currentnode == nullptr){
        std::cout << "Playlist is empty. \n";
        return;
    }
    currentnode = currentnode->prev;
    std::cout << "Currently Playing: " << currentnode->data << " by " << currentnode->artist << "\n";
};

// View all songs 
template <typename T>
void view_all_music(music_playlist<T>* currentnode){
    if (currentnode == nullptr){
        std::cout << "Playlist is empty. \n";
        return;
    }
    music_playlist<T>* start = currentnode;
    int song = 1;
    do {
        std::cout << song << "." << currentnode->data << " by " << currentnode->artist << "\n";
        song++;
        currentnode = currentnode->next;
    } while (currentnode != start);
};

template <typename T>
void Del_music(int pos, music_playlist<T>** currenthead){
    if (*currenthead == nullptr){
        std::cout << "Playlist is empty.";
        return;
    }
    
    if (pos < 1) {
        std::cout << "Invalid position.\n";
        return;
    }

    music_playlist<T>* currentnode = *currenthead;
    //move to the selected position
    for(int i = 1; i < pos; i++){
        currentnode = currentnode->next;
        if (currentnode == *currenthead) {
            std::cout << "Position out of bounds.\n";
            return;
        }
    }

    if(currentnode->next == currentnode){
        *currenthead = nullptr;
        delete currentnode;
        return;
    }

    currentnode->prev->next = currentnode->next;
    currentnode->next->prev = currentnode->prev;

    if (currentnode == *currenthead){
        *currenthead = currentnode->next;
    }
    delete currentnode;
};

#endif