#include <iostream>
#include <string>
#include <stack>
#include <unordered_map>
#include <iomanip>

#define MAX_SIZE 100

// matching pairs, assigning delimiters for character pairings
const std::unordered_map<char, char> pair = {
    {')', '('},
    {']', '['},
    {'}', '{'}
};

// categorizing the characters
// for opening characters
bool isOpening(char ch) {
    return ch == '(' || ch == '[' || ch == '{';
}

// for closing characters
bool isClosing(char ch) {
    return pair.count(ch) > 0;
}

// Stack using array
class Array {
private:
    //array that stacks pushed elements
    char arr[MAX_SIZE];
    int topIndex;

public:
    //top is always -1 of the array size
    Array() : topIndex(-1) {}

    //pushing function
    bool push(char val) {
        //checks if the top reaches max size, full returns false
        if (topIndex >= MAX_SIZE - 1) return false;
        arr[++topIndex] = val;
        return true;
    }
    //popping function
    char pop() {
        //if empty, returns null value
        if (isEmpty()) return '\0';
        return arr[topIndex--];
    }
    //top function
    char top() const {
        if (isEmpty()) return '\0';
        return arr[topIndex];
    }
    //isEmpty function
        //returns true if value is less than 0
    bool isEmpty() const {
        return topIndex < 0;
    }
};

bool checkArray(const std::string& expr) {
    Array stack;
    for (char ch : expr) {
        if (isOpening(ch)) {
            stack.push(ch);
        } else if (isClosing(ch)) {
            if (stack.isEmpty() || stack.pop() != pair.at(ch)) {
                return false;
            }
        }
    }
    return stack.isEmpty();
}

// Linked list
struct Node {
    char data;
    Node* next;
};

class LinkedList {
private:
    Node* topNode;

public:
    LinkedList() : topNode(nullptr) {}

    ~LinkedList() {
        while (!isEmpty()) {
            pop();
        }
    }
    //pushing
    void push(char val) {
        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = topNode;
        topNode = newNode;
    }
    //popping
    char pop() {
        if (isEmpty()) return '\0';
        Node* temp = topNode;
        char poppedVal = temp->data;
        topNode = topNode->next;
        delete temp;
        return poppedVal;
    }
    //isEmpty
    bool isEmpty() const {
        return topNode == nullptr;
    }
};

bool checkLinkedList(const std::string& expr) {
    LinkedList stack;
    for (char ch : expr) {
        if (isOpening(ch)) {
            stack.push(ch);
        } else if (isClosing(ch)) {
            if (stack.isEmpty() || stack.pop() != pair.at(ch)) {
                return false;
            }
        }
    }
    return stack.isEmpty();
}

//C++ STL
bool checkSTL(const std::string& expr) {
    std::stack<char> s;
    for (char ch : expr) {
        if (isOpening(ch)) {
            s.push(ch);
        } else if (isClosing(ch)) {
            if (s.empty() || s.top() != pair.at(ch)) {
                return false;
            }
            s.pop();
        }
    }
    return s.empty();
}

//MAIN FUNCTION
int main() {
    std::string testCases[] = {
        "(A+B)+(C-D)",
        "((A+B)+(C-D)",
        "((A+B)+[C-D])",
        "((A+B]+[C-D]}"
    };

    
    std::cout << "-----------------------SYMBOL BALANCING TEST SUITE-----------------------\n\n";
    
    std::cout << std::left 
              << std::setw(22) << "Expression" 
              << std::setw(16) << "Array Stack" 
              << std::setw(22) << "Linked List Stack" 
              << std::setw(16) << "STL Stack" 
              << "\n";
    std::cout << "-------------------------------------------------------------------------\n";

    for (const std::string& expr : testCases) {
        bool resArray = checkArray(expr);
        bool resLL    = checkLinkedList(expr);
        bool resSTL   = checkSTL(expr);
        //formatting
        std::cout << std::left 
                  << std::setw(22) << expr 
                  << std::setw(16) << (resArray ? "Valid (Y)" : "Invalid (N)")
                  << std::setw(22) << (resLL    ? "Valid (Y)" : "Invalid (N)")
                  << std::setw(16) << (resSTL   ? "Valid (Y)" : "Invalid (N)")
                  << "\n";
    }

    return 0;
}