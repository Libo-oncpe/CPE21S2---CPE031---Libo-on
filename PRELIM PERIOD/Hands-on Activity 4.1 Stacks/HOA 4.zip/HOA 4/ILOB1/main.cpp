#include <iostream>

//global declarations
#define maxCap 100 
int stackArr[maxCap];
int top = -1, newData;

//prototype functions
void push();
void pop();
void Top();
bool isEmpty();
bool isFull();
void display();

int main(){
    //main driver code
int choice;
    while(true){
        std::cout << "\n+++++++++++++++++++++++++++++++++++++++++++++++++" << std::endl;
        std::cout << "Stack Operations \n"; 
        std::cout << "1. Push 2. Pop 3. Top 4. isEmpty 5. isFull 6. Display 7. End" << std::endl;
        std::cout << "+++++++++++++++++++++++++++++++++++++++++++++++++\n";
        std::cin >> choice;

        switch (choice){
            case 1: push();
            break;
            case 2: pop();
            break;
            case 3: Top();
            break;
            case 4: std::cout << "is stack empty? " << isEmpty() << std::endl;
            break;
            case 5: std::cout << "Is the stack full? " << isFull() << std::endl;
            break;
            case 6: display(); 
            break;
            case 7: return 0;
            break;
            default: std::cout << "Invalid Choice" << std::endl;
        }
    }
}


//function definition
bool isEmpty(){
    if(top == -1) return true;
    return false;
}

bool isFull(){
    if (top == maxCap - 1) return true;
    return false;
}

void push(){
    if (isFull()){
        std::cout << "Stack Overflow!" << std::endl;
        return;
    }

    std::cout << "Enter a new value: " << std::endl;
    std::cin >> newData;
    stackArr[++top] = newData;
}

void pop(){
    if(isEmpty()){
        std::cout << "Stack Underflow!" << std::endl;
    }

    //display the value that we are going to pop.
    std::cout << "Popping: " << stackArr[top] << std::endl;
    //decrement the top value from the stack
    top--;
}

void Top(){
    //error catching:
    if(isEmpty()){
        std::cout << "The stack is empty." << std::endl;
        return;
    }

    std::cout << "Top Element: " << stackArr[top]<<std::endl;
}

void display(){
    if(isEmpty()){
        std::cout << "The stack is empty." << std::endl;
        return;
    }
    std::cout << "This is the content of your stack: ";
    
    for (int i = top; i >= 0; i--){
        std::cout << stackArr[i];
    }
    std::cout << std::endl;
}