#ifndef STACK_H
#define STACK_H

#include <iostream>

template <typename T>
class Node {
    public:
    T data; //stored value
    Node* next; //pointer to next
};

//pointer for the top 
template <typename T>
Node<T>* head = nullptr;

//stack operations

//pushing
template <typename T>
void push(T newData) {
    //creating new node and assigning new data
    Node<T>* newNode = new Node<T>();
    newNode->data = newData;

    //points to the current top which will become the new top
    newNode->next = head<T>;
    head<T> = newNode;
}

//popping

template <typename T>
T pop() {
    //checks if stack is empty
    if (head<T> == nullptr) {
        std::cerr << "Error. Cannot pop from an empty stack." << std::endl;
    }

    //saving the top node
    Node<T>* temp = head<T>;
    T tempVal = temp->data;

    //move to the next node
    head<T> = head<T>->next;

    delete temp;

    return tempVal;
}

//isEmpty
template <typename T>
bool isEmpty() {
    return head<T> == nullptr;
}

//Top
template <typename T>
void Top() {
    if (head<T> == nullptr) {
        std::cout << "Stack is empty." << std::endl;
        return;
    }
    std::cout << "Top element: " << head<T>->data << std::endl;
}

//display all
template <typename T>
void displayALL() {
    if (head<T> == nullptr) {
        std::cout << "Stack is Empty.\n" << std::endl;
        return;
    }

    //traverse and display
    Node<T>* temp = head<T>;
    std::cout << "Stack elements: \n";
    while (temp != nullptr) {
        std::cout << temp->data << " \n";
        temp = temp->next;
    }
    std::cout << std::endl;
}

#endif