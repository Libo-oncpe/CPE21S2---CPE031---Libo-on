#include <iostream>
#include "stack_ll.h"

int main() {
    
    std::cout << "Pushing Elements into the Stack\n";

    //pushing elements
    push('C');
    push('P');
    push('E');

    //Displaying the top
    Top<char>; 
    displayALL<char>();
    std::cout << "Element Popping\n";

    //popping elements until empty
    while(!isEmpty<char>()) {
        std::cout<<"Popped: "<< pop<char>() <<std::endl;
    }

    //checks if the stack is underflowing
    std::cout << "\nUnderflow Condition\n";
    pop<char>();

    return 0;
}