#include <iostream>
#include <string>
#include "GeneralTree.h"

// Print tree structure
void printTree(GeneralTree<char>* node, int depth = 0) {
    if (node == nullptr) return;

    // Print current node with indentation
    for (int i = 0; i < depth; ++i) std::cout << "  ";
    std::cout << node->getRootVal() << std::endl;

    // Print first child
    printTree(node->getLeftChild(), depth + 1);

    // Print next sibling
    printTree(node->getRightChild(), depth);
}

int main() {
    //Create Root Node 'A'
    GeneralTree<char>* A = new GeneralTree<char>('A');

    //Attach Children to A
    A->insertLeftChild('B');
    GeneralTree<char>* B = A->getLeftChild();

    B->insertRightChild('C');
    GeneralTree<char>* C = B->getRightChild();

    C->insertRightChild('D');
    GeneralTree<char>* D = C->getRightChild();

    D->insertRightChild('E');
    GeneralTree<char>* E = D->getRightChild();

    E->insertRightChild('F');
    GeneralTree<char>* F = E->getRightChild();

    F->insertRightChild('G');
    GeneralTree<char>* G = F->getRightChild();

    //Insert Subtrees
    D->insertLeftChild('H');

    E->insertLeftChild('I');
    GeneralTree<char>* I = E->getLeftChild();
    I->insertRightChild('J');
    GeneralTree<char>* J = I->getRightChild();

    J->insertLeftChild('P');
    GeneralTree<char>* P = J->getLeftChild();
    P->insertRightChild('Q');

    F->insertLeftChild('K');
    GeneralTree<char>* K = F->getLeftChild();
    K->insertRightChild('L');
    GeneralTree<char>* L = K->getRightChild();
    L->insertRightChild('M');

    //attach O as N's sibling
    G->insertLeftChild('N');
    GeneralTree<char>* N = G->getLeftChild();
    N->insertRightChild('O');

    //Print General Tree Structure
    std::cout << "General Tree Structure: " << std::endl;
    printTree(A);
    std::cout << "\n\n";

    //Print Traversals
    std::cout << "Pre-Order Traversal:  ";
    preOrder(A);
    std::cout << "\n\n";

    std::cout << "In-Order Traversal:   ";
    inOrder(A);
    std::cout << "\n\n";

    std::cout << "Post-Order Traversal: ";
    postOrder(A);
    std::cout << "\n\n";
    
    //Testing findData with node 'O'
    std::cout << "Find Results" << std::endl;
    findData<char>(A, "PRE", 'E');
    findData<char>(A, "IN", 'E');
    findData<char>(A, "POST", 'E');

    findData<char>(A, "PRE", 'O');
    findData<char>(A, "IN", 'O');
    findData<char>(A, "POST", 'O');
    
    //destructor
    delete A;

    return 0;
}