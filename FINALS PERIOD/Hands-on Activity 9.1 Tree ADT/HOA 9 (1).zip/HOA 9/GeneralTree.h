#ifndef GENERALTREE_H
#define GENERALTREE_H

#include <iostream>
#include <string>

template <typename T>
class GeneralTree {
private:
    T key;
    // Pointers for First-Child 
    GeneralTree<T>* firstChild;
    GeneralTree<T>* nextSibling;

public:
    // Constructor
    GeneralTree(T rootObj);

    // Destructor
    ~GeneralTree();

    // Inserting a child node or sibling node
    void insertLeftChild(T newNode);
    void insertRightChild(T newNode);

    GeneralTree<T>* getLeftChild();
    GeneralTree<T>* getRightChild();

    T getRootVal();

    void setRootVal(T obj);

    bool isleaf();
};

template <typename T>    
GeneralTree<T>::GeneralTree(T rootObj) {
    key = rootObj;
    firstChild = nullptr;
    nextSibling = nullptr;
}

template <typename T>
GeneralTree<T>::~GeneralTree() {
    delete firstChild;
    delete nextSibling;
}

template <typename T>
void GeneralTree<T>::insertLeftChild(T newNode) {
    if (firstChild == nullptr) {
        firstChild = new GeneralTree<T>(newNode);
    } else {
        // Push existing firstChild to nextSibling slot
        GeneralTree<T>* newChild = new GeneralTree<T>(newNode);
        newChild->nextSibling = firstChild;
        firstChild = newChild;
    }
}

template <typename T>
void GeneralTree<T>::insertRightChild(T newNode) {
    if (nextSibling == nullptr) {
        nextSibling = new GeneralTree<T>(newNode);
    } else {
        // Push existing nextSibling down
        GeneralTree<T>* newChild = new GeneralTree<T>(newNode);
        newChild->nextSibling = nextSibling;
        nextSibling = newChild;
    }
}

template <typename T>
GeneralTree<T>* GeneralTree<T>::getLeftChild() {
    return firstChild;
}

template <typename T>
GeneralTree<T>* GeneralTree<T>::getRightChild() {
    return nextSibling;
}

template <typename T>
T GeneralTree<T>::getRootVal() {
    return key;
}

template <typename T>
void GeneralTree<T>::setRootVal(T obj) {
    key = obj;
}

template <typename T>
bool GeneralTree<T>::isleaf() {
    return firstChild == nullptr && nextSibling == nullptr;
}

// TREE TRAVERSAL FUNCTIONS

// PRE-ORDER TRAVERSAL 
template <typename T>
void preOrder(GeneralTree<T>* node) {
    if (node == nullptr) return;

    std::cout << node->getRootVal() << " ";

    preOrder(node->getLeftChild());
    preOrder(node->getRightChild());
}

// IN-ORDER TRAVERSAL 
template <typename T>
void inOrder(GeneralTree<T>* node) {
    if (node == nullptr) return;

    inOrder(node->getLeftChild());

    std::cout << node->getRootVal() << " ";

    inOrder(node->getRightChild());
}

// POST-ORDER TRAVERSAL
template <typename T>
void postOrder(GeneralTree<T>* node) {
    if (node == nullptr) return;

    postOrder(node->getLeftChild());
    postOrder(node->getRightChild());

    std::cout << node->getRootVal() << " ";
}

//MAIN SEARCH FUNCTION

template <typename T>
bool findDataHelper(GeneralTree<T>* node, const std::string& choice, T key) {
    if (node == nullptr) return false;

    // PRE-ORDER
    if (choice == "PRE" || choice == "pre") {
        if (node->getRootVal() == key) return true;
        if (findDataHelper(node->getLeftChild(), choice, key)) return true;
        if (findDataHelper(node->getRightChild(), choice, key)) return true;
    }
    // IN-ORDER
    else if (choice == "IN" || choice == "in") {
        if (findDataHelper(node->getLeftChild(), choice, key)) return true;
        if (node->getRootVal() == key) return true;
        if (findDataHelper(node->getRightChild(), choice, key)) return true;
    }
    // POST-ORDER
    else if (choice == "POST" || choice == "post") {
        if (findDataHelper(node->getLeftChild(), choice, key)) return true;
        if (findDataHelper(node->getRightChild(), choice, key)) return true;
        if (node->getRootVal() == key) return true;
    }

    return false;
}

template <typename T>
void findData(GeneralTree<T>* root, std::string choice, T key) {
    if (findDataHelper(root, choice, key)) {
        std::cout << key << " was found!" << std::endl;
    }
}

#endif