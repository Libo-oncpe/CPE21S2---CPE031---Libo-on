#include <iostream>
#include "binaryTree.h"

int main(){


    BinaryTree<char>* root = new BinaryTree<char>('A');


    root->insertLeftChild('B');
    root->insertRightChild('C');


    root->getLeftChild()->insertLeftChild('D');
    root->getLeftChild()->insertRightChild('F');

    root->getRightChild()->insertLeftChild('E');

    std::cout << "Root value: " << root->getKey() << '\n';
    std::cout << "Left child of root: " << root->getLeftChild()->getKey() << '\n';
    std::cout << "Right child of root: " << root->getRightChild()->getKey() << '\n';

    std::cout << "Left child of root: " << root->getLeftChild()->getLeftChild()->getKey() << '\n';
    std::cout << "Right child of root: " << root->getLeftChild()->getRightChild()->getKey() << '\n';

    root->getLeftChild()->getRightChild()->changeKey('K');
    std::cout << "Right child of root: " << root->getLeftChild()->getRightChild()->getKey() << '\n';
    return 0;
}